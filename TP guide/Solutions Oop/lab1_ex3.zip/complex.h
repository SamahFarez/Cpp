#ifndef COMPLEX_H
#define COMPLEX_H

class Complex {
    public:
        Complex( double = 0., double = 0.);
        void set(double, double);
        void print();
        void add(const Complex &);
        void sub(const Complex &);
        void mult(const Complex &);
    private:
        double real;
        double imaginary;
};

#endif // COMPLEX_H
