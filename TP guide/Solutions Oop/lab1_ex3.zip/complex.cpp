#include "complex.h"
#include <iostream>
using namespace std;

Complex::Complex(double r, double i) {
    set(r, i);
}

void Complex::set(double r, double i) {
    real = r;
    imaginary = i;
}

void Complex::print() {
    cout << "( " << real << ", " << imaginary << " )";
}

void Complex::add(const Complex &c) {
    real = real + c.real;
    imaginary = imaginary + c.imaginary;
}

void Complex::sub(const Complex &c) {
    real = real - c.real;
    imaginary = imaginary - c.imaginary;
}

void Complex::mult(const Complex &c) {
    // It is important to save real before modifying it because the old value
    // is used to compute the new value of imaginary
    double oldReal = real;
    real = real * c.real - imaginary * c.imaginary ;
    imaginary = oldReal * c.imaginary + imaginary * c.real;
}
