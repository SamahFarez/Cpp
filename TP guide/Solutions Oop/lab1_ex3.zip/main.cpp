#include "complex.h"
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
    Complex c1(-1, -1);
    cout << "c1 = ";
    c1.print();
    cout << endl;

    Complex c2(3, 2);
    cout << "c2 = ";
    c2.print();
    cout << endl;

    Complex c3(0.5, -2);
    cout << "c3 = ";
    c3.print();
    cout << endl;

    Complex c4(-5, 1.2);
    cout << "c4 = ";
    c4.print();
    cout << endl;

    c1.add(c2);
    cout << "c1 + c2 = ";
    c1.print();
    cout << endl;

    c2.sub(c3);
    cout << "c2 - c3 = ";
    c2.print();
    cout << endl;

    c3.mult(c4);
    cout << "c3 * c4 = ";
    c3.print();
    cout << endl;

    return 0;
}
