#include "rational.h"
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
    Rational r1(10, 6);
    cout << "r1 = ";
    r1.print();
    cout << endl;

    Rational r2(-2, 1);
    cout << "r2 = ";
    r2.print();
    cout << endl;

    Rational r3 = r1.add(r2);
    cout << "r3 = r1 + r2 = ";
    r3.print();
    cout << " = ";
    r3.printFloat();
    cout << endl;

    Rational r4 = r3.sub(r1);
    cout << "r4 = r3 - r1 = ";
    r4.print();
    cout << endl;

    Rational r5 = r3.mult(r1);
    cout << "r5 = r3 * r1 = ";
    r5.print();
    cout << endl;


    Rational r6 = r5.div(r3);
    cout << "r6 = r5 / r3 = ";
    r6.print();
    cout << endl;

    return 0;
}
