#include "rational.h"
#include <iostream>
using namespace std;

Rational::Rational(int n, int d) {
    numerator = n;
    if (d == 0) {
        denominator = 1;
    } else {
        denominator = d;
    }
    reduce();
}

void Rational::reduce() {
    int gcd = 1;
    int a = (numerator >= 0) ? numerator : -numerator;
    int b = (denominator >= 0) ? denominator : -denominator;
    for (gcd = a; gcd >= 1; gcd--) {
        if (a % gcd == 0 && b % gcd == 0) {
            break;
        }
    }
    numerator = numerator / gcd;
    denominator = denominator / gcd;
}

void Rational::print() {
    if (numerator == 0) {
        cout << 0;
    } else {
        if (denominator == 1) {
            cout << numerator;
        } else {
            cout << numerator << " / " << denominator;
        }
    }
}

Rational Rational::add(const Rational &r) {
    int a = numerator * r.denominator + r.numerator * denominator;
    int b = denominator * r.denominator;
    Rational result(a, b);
    return result;
}

Rational Rational::sub(const Rational &r) {
    return Rational(numerator * r.denominator - r.numerator * denominator, denominator * r.denominator);
}

Rational Rational::mult(const Rational &r) {
    return Rational(numerator * r.numerator, denominator * r.denominator);
}

Rational Rational::div(const Rational &r) {
    return Rational(numerator * r.denominator, denominator * r.numerator);
}

void Rational::printFloat() {
    double d = (double)numerator / (double)denominator;
    cout << d;
}
