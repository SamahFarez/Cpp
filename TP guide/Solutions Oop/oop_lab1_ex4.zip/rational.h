#ifndef _RATIONAL_H_
#define _RATIONAL_H_

class Rational {
    public:
        Rational(int = 0, int = 1);
        void print();
        void printFloat();
        Rational add(const Rational &);
        Rational sub(const Rational &);
        Rational mult(const Rational &);
        Rational div(const Rational &);

    private:
        int numerator;
        int denominator;
        void reduce();
};

#endif // _RATIONAL_H_
