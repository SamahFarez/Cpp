
#include "cat.h"

#include <cstdlib>
#include <cstring>
#include <ctime>

// constructor
Cat::Cat()
{
    srand(time(0));
    setFurColor();
    setEyeColor();
    setHairLength();

} // end class Cat constructor

// return fur color
const char* Cat::getFurColor() const
{
    return furColor;
} // end function getFur

// return hair length
const char* Cat::getHairLength() const
{
    return hairLength;
} // end function getHairLength

// return eye color
const char* Cat::getEyeColor() const
{
    return eyeColor;
} // end function getEyeColor

// set fur color
void Cat::setFurColor()
{
    int x = rand() % 3;

    if (x == 0)
       furColor = "black";

    else if (x == 1)
        furColor = "grey";

    else
        furColor = "brown";

} // end function setFurColor

// set eye color
void Cat::setEyeColor()
{
    int x = rand() % 3;

    if (x == 0)
        eyeColor = "blue";

    else if (x == 1)
        eyeColor = "brown";

    else
        eyeColor = "green";

} // end function setEyeColor

// set hair length
void Cat::setHairLength()
{
    int x = rand() % 2;

    if (x == 0)
        hairLength = "short";

    else
        hairLength = "long";

} // end function setHairLength

