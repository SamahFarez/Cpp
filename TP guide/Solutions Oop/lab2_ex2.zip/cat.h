#ifndef CATS_H
#define CATS_H

// class Cat definition
class Cat {

public:
    Cat();
    const char* getFurColor() const;
    const char* getHairLength() const;
    const char* getEyeColor() const;
  
private:
    void setFurColor();
    void setHairLength();
    void setEyeColor();
    const char * furColor;
    const char * hairLength;
    const char * eyeColor;

}; // end class Cat

#endif // CATS_H

