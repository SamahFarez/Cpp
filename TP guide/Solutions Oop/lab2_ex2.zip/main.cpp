#include <iostream>

using std::cout;
using std::cin;
using std::endl;

#include <cstring>

#include "cat.h"

// Function prototype for check
void check(Cat* cats[], int);


int main() {
    // srand( time( 0 ) );
    const int roomSize = 10;
    Cat* cats[roomSize];

    for (int count = 0; count < roomSize; count++) {
        // Allocate a new Cat instance
        cats[count] = new Cat;

        // Print cat characteristics
        cout << "Cat is " << cats[count]->getFurColor();
        cout << " with " << cats[count]->getEyeColor() << " eyes";
        cout << " and " << cats[count]->getHairLength() << " hair" << endl;

        // Check if there is a fight
        check(cats, count);

        cout << "Press a key to add the next cat to the room." << endl;
        cin.get();

    }


    // Delete allocated objects
    for (int i = 0; i < roomSize /* don't exceed array size*/; i++) {
        delete cats[i];
    }

    return 0;
}

// Function to check whether there is a fight
void check(Cat* cats[], int numberOfCats) {
    // Number of grey cats
    int nbGrey = 0;
    // Number of brown cats
    int nbBrown = 0;
    // Number of black cats with green eyes
    int nbBlackGreen = 0;
    // Number of black cats with blue eyes
    int nbBlackBlue = 0;
    // Number of black cats with brown eyes
    int nbBlackBrown = 0;

    // Iterate over Cat instances and count particular cases
    for (int i = 0; i <= numberOfCats; i++) {
        if (strcmp(cats[i]->getFurColor(), "grey") == 0)
            nbGrey++;
        else if (strcmp(cats[i]->getFurColor(), "brown") == 0)
            nbBrown++;

        if (strcmp(cats[i]->getFurColor(), "black") == 0) {
            if (strcmp(cats[i]->getEyeColor(), "green") == 0) {
                nbBlackGreen++;
            }
        }
        else if (strcmp(cats[i]->getEyeColor(), "blue") == 0) {
            nbBlackBlue++;
        }
        else nbBlackBrown++;
    }

    if (nbGrey > nbBrown && nbBrown > 0)
        cout << "The " << nbGrey << " grey and " << nbBrown << " 
        brown cats are fighting!!" << endl;

    if (nbBlackBrown == 1 && nbBlackGreen >= 1 && nbBlackBlue >= 1)
        cout << "The black cat(s) with blue eyes and the black cat(s) with green eyes are fighting with the black cat that has brown eyes." << endl;

}
