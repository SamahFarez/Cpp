#include <iostream>
#include "polynomial.h"

using namespace std;

int main() {
  Polynomial a, b, c, t;
  a.enterTerms();
  b.enterTerms();
  t = a; // save value of a
  cout << "\n First Polynomial is  : \n ";
  a.printPolynomial();

  cout << "\n Second Polynomial is  : \n ";
  b.printPolynomial();

  cout << "\nAdding the Polynomials yields   : \n ";
  c = a + b;
  c.printPolynomial();

  cout << "\n +=  the Polynomials yields   : \n ";
  a += b;
  a.printPolynomial();

  cout << "\n Subtracting  the Polynomials yields   : \n ";
  a = t; // reset a to original value
  c = a - b;
  c.printPolynomial();

  cout << "\n -=  the Polynomials yields   : \n ";
  a -= b;
  a.printPolynomial();

  cout << "\n Multiplying the Polynomials yields   : \n ";
  a = t; // reset a to original value
  c = a * b;
  c.printPolynomial();

  cout << "\n *=  the Polynomials yields   : \n ";
  a *= b;
  a.printPolynomial();
  cout << endl;
  return 0;
}
