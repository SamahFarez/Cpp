#ifndef POLYNOMIAL_H_INCLUDED
#define POLYNOMIAL_H_INCLUDED

class Polynomial {
public:
  Polynomial();
  Polynomial operator+(const Polynomial &);
  Polynomial operator-(const Polynomial &);
  Polynomial operator*(const Polynomial &);
  const Polynomial operator=(const Polynomial &);
  Polynomial &operator+=(const Polynomial &);
  Polynomial &operator-=(const Polynomial &);
  Polynomial &operator*=(const Polynomial &);
  void enterTerms(void); // input terms of polynomial
  void printPolynomial(void);

private:
  int exponents[100];
  int coefficients[100];
  void polynomialCombine(Polynomial &); // combine common terms
};

#endif // POLYNOMIAL_H_INCLUDED
