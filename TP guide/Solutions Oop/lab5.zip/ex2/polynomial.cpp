#include <iostream>
#include "polynomial.h"
# include <iomanip>

using namespace std;

// Set all the terms of the polynomial to 0
Polynomial::Polynomial() {
  for (int t = 0; t < 100; t++) {
    exponents[t] = 0;
    coefficients[t] = 0;
  }
}

void Polynomial::enterTerms(void) // input terms of polynomial

{
  bool found = false;
  int numberOfterms, c, e;
  cout << "\n Enter the number of polynomial terms  : ";
  cin >> numberOfterms;

  for (int n = 1; n <= numberOfterms; ++n) {
    cout << "\n Enter coefficient  : ";
    cin >> c;
    cout << " Enter exponent     : ";
    cin >> e;
    if (c != 0) {
      // exponent zero at first element
      if (e == 0) {
        coefficients[0] += c;
        continue;
      }
      int term;
      for (term = 1; (term < 100) && (coefficients[term] != 0); term++)
        if (e == exponents[term]) {
          coefficients[term] += c;
          found = true;
        }
      if (!found) // add term
      {
        coefficients[term] += c;
        exponents[term] = e;
      }
    }
  }
}
void Polynomial::printPolynomial(void) {
  int start;
  bool zero = false;
  if (coefficients[0] != 0) { // output constant
    cout << coefficients[0];
    start = 1;
    zero = true;                     // at least one term exist
  } else if (coefficients[1] != 0) { // output term1 without sign
    cout << coefficients[1] << "x";
    if (exponents[1] != 0 && exponents[1] != 1) {
      cout << "^" << exponents[1];
    }
    zero = true;
    start = 2;
  }
  // output remaining polynomial terms
  for (int x = start; x < 100; x++)
    if (coefficients[x] != 0) { // output term with sign
      cout << setiosflags(ios::showpos) << coefficients[x]
           << resetiosflags(ios::showpos) << "x";
      if (exponents[x] != 0 && exponents[x] != 1) {
        cout << "^" << exponents[x];
      }
      zero = true;
    }

  if (!zero)
    cout << "0";
  cout << endl;
}

const Polynomial Polynomial::operator=(const Polynomial &r) {
  exponents[0] = r.exponents[0];
  coefficients[0] = r.coefficients[0];
  for (int i = 1; i < 100; i++)
    if (r.exponents[i] != 0) {
      exponents[i] = r.exponents[i];
      coefficients[i] = r.coefficients[i];
    } else {
      if (exponents[i] == 0)
        break;
      exponents[i] = 0;
      coefficients[i] = 0;
    }
  return *this;
}
Polynomial Polynomial::operator+(const Polynomial &r) {
  Polynomial temp;
  bool exponentexist;
  temp.coefficients[0] = coefficients[0] + r.coefficients[0];
  int i;
  for (i = 1; (i < 100) && (r.exponents[i] != 0); i++) {
    temp.exponents[i] = r.exponents[i];
    temp.coefficients[i] = r.coefficients[i];
  }

  for (int x = 1; (x < 100); x++) {
    exponentexist = false;

    for (int t = 1; (t < 100) && (!exponentexist); t++)
      if (exponents[x] == temp.exponents[t]) {
        exponentexist = true;
        temp.coefficients[t] += coefficients[x];
      }
    if (!exponentexist) {
      temp.exponents[i] = exponents[x];
      temp.coefficients[i] = coefficients[x];
      i++;
    }
  }
  return temp;
}

Polynomial &Polynomial::operator+=(const Polynomial &r) {
  *this = *this + r;
  return *this;
}

Polynomial Polynomial::operator-(const Polynomial &r) {
  Polynomial temp;
  bool exponentexist;
  temp.coefficients[0] = coefficients[0] - r.coefficients[0];
  int i;
  for (i = 1; (i < 100) && (exponents[i] != 0); i++) {
    temp.exponents[i] = exponents[i];
    temp.coefficients[i] = coefficients[i];
  }

  for (int x = 1; (x < 100); x++) {
    exponentexist = false;

    for (int t = 1; (t < 100) && (!exponentexist); t++)
      if (r.exponents[x] == temp.exponents[t]) {
        exponentexist = true;
        temp.coefficients[t] -= r.coefficients[x];
      }

    if (!exponentexist) {
      temp.exponents[i] = r.exponents[x];
      temp.coefficients[i] -= r.coefficients[x];
      i++;
    }
  }
  return temp;
}

Polynomial &Polynomial::operator-=(const Polynomial &r) {
  *this = *this - r;
  return *this;
}

Polynomial Polynomial::operator*(const Polynomial &r)

{
  Polynomial temp;
  int s = 1; // subscript for temp

  for (int x = 0; (x < 100) && (x == 0 || coefficients[x] != 0); x++)

    for (int y = 0; (y < 100) && (y == 0 || r.coefficients[y] != 0); y++)

      if ((coefficients[x] * r.coefficients[y]) != 0) {

        if ((exponents[x] == 0) && (r.exponents[y] == 0)) {
          temp.coefficients[0] += coefficients[x] * r.coefficients[y];
        }

        else {
          temp.coefficients[s] = coefficients[x] * r.coefficients[y];
          temp.exponents[s] = exponents[x] + r.exponents[y];
          ++s;
        }
      }

  polynomialCombine(temp);
  return temp;
}

void Polynomial::polynomialCombine(Polynomial &w)

{
  Polynomial temp = w;

  for (int x = 0; x < 100; x++) {
    w.coefficients[x] = 0;
    w.exponents[x] = 0;
  }
  int exp;
  for (int x = 1; x < 100; x++) {
    exp = temp.exponents[x];
    for (int y = x + 1; y < 100; y++) {
      if (exp == temp.exponents[y]) {
        temp.coefficients[x] += temp.coefficients[y];
        temp.exponents[y] = 0;
        temp.coefficients[y] = 0;
      }
    }
  }

  w.coefficients[0] = temp.coefficients[0];
  int s = 1;
  for (int x = 0; x < 100; x++)
    if (temp.exponents[x] != 0 && temp.coefficients[x] != 0)

    {
      w.coefficients[s] = temp.coefficients[x];
      w.exponents[s] = temp.exponents[x];
      s++;
    }
}

Polynomial &Polynomial::operator*=(const Polynomial &r)

{
  *this = *this * r;
  return *this;
}

