#ifndef RATIONAL_H_
#define RATIONAL_H_

#include <iostream>

class Rational {
    friend std::ostream& operator<<(std::ostream&, const Rational&);
    public:
        Rational(int = 0, int = 1);
        Rational operator+(const Rational&);
        Rational operator-(const Rational&);
        Rational operator-();
        Rational& operator+=(const Rational&);
        Rational& operator++();
        Rational operator++(int);
        bool operator>(const Rational&);
        bool operator==(const Rational&);
        operator int();
        operator float();

    private:
        int numerator;
        int denominator;
        void set(int, int);
};


#endif // RATIONAL_H_
