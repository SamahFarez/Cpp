#include "rational.h"
#include <iostream>
#include <ostream>


Rational::Rational(int a, int b) {
    if (b == 0) {
        std::cerr << "Division by zero" << std::endl;
        b = 1;
    }
    set(a, b);
}

void Rational::set(int a, int b) {
    numerator = a;
    denominator = b;
    a = a > 0 ? a : -a;
    b = b > 0 ? b : -b;
    if (a == 0) {
        return;
    }
    int gcd = 1;
    for(gcd = a; gcd >= 2; gcd--) {
        if (a % gcd == 0 && b % gcd == 0) {
            break;
        }
    }
    numerator = numerator / gcd;
    denominator = denominator / gcd;
    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }
}

std::ostream& operator<<(std::ostream& out, const Rational& r) {
    out << r.numerator;
    if (r.denominator != 1) {
        out << "/" << r.denominator;
    }
    return out;
                        }

Rational Rational::operator+(const Rational & r) {
    return Rational(numerator*r.denominator + r.numerator * denominator, denominator * r.denominator);
}

Rational Rational::operator-(const Rational & r) {
    return Rational(numerator*r.denominator - r.numerator * denominator, denominator * r.denominator);
}

Rational Rational::operator-() {
    return Rational(-numerator, denominator);
}

Rational& Rational::operator+=(const Rational & r) {
    set(numerator*r.denominator + r.numerator * denominator, denominator * r.denominator);
    return *this;
}

Rational& Rational::operator++() {
    set(numerator + denominator, denominator);
    return *this;
}

Rational Rational::operator++(int dummy) {
    Rational tmp(numerator, denominator);
    set(numerator + denominator, denominator);
    return tmp;
}

bool Rational::operator>(const Rational & r) {
    Rational diff = *this - r;
    return diff.numerator > 0;
}

bool Rational::operator==(const Rational & r) {
    return numerator == r.numerator && denominator == r.denominator;
}

Rational::operator int() {
    return numerator/denominator;
}

Rational::operator float() {
    return (float)numerator/denominator;
}
