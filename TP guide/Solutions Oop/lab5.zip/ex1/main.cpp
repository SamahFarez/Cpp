#include "rational.h"
#include <iostream>
using namespace std;

int main() {
    Rational c(7,3) ,d(4,-7),result;
    cout<< "d: " << d <<endl;
    d= -d;
    cout<<"-d :  "<<  d <<endl;
    cout << c;
    cout << " + ";
    cout<< d;
    result = c+d;
    cout << " = ";
    cout<<result;
    cout << "\n";

    cout << c;
    cout << " + ";
    cout<< d;
    cout << " + ";
    cout  << Rational(5,2);
    result = c+d + Rational(5,2) ;
    cout << " = ";
    cout<<result;
    cout << "\n";

    cout<< c ;
    cout << " - ";
    cout<< d;
    result = c-d;
    cout << " = ";
    cout<<result;
    cout << "\n";

    
	cout << c;
	cout << " is  : \n ";
	cout <<"\t"<< (c>d ? " >  ": " <= ");
	cout<<d ;
	cout << "\t according to the overloaded > operator  \n ";

	cout <<"\t"<< (c==d ? " == ": " != ");
	cout<<d ;
	cout << "\t according to the overloaded == operator  \n ";

	Rational r(11,4);
	cout<< "Conversion of " << r << " to  : \n ";
	cout <<"\t"<< "integer value is :  " << int(r) <<endl;
    	cout <<"\t"<< "float value is   :  " << float(r) <<endl;
    	

    // testing preincrement postincrement

    cout << "\n Testing the preincrement operator :  \n "
         << "\t c is  " << c << "\n";
    cout  << "\t ++c is " << ++c<< "\n" ;
    cout <<  "\t c is  " << c << "\n";

    cout << "\n Testing the postincrement operator :  \n "
         << "\t d is  " << d << "\n";
    cout  << "\t d++ is " << d++<< "\n" ;
    cout <<  "\t d is  " << d << "\n";


    return 0;
}
