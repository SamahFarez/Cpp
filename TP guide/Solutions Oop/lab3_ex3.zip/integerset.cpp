#include "integerset.h"
#include <iostream>

IntegerSet::IntegerSet() {
    for(int i = MIN; i <= MAX; i++) {
        data[i] = 0;
    }
}

IntegerSet IntegerSet::unionOfSets(const IntegerSet & other) {
    IntegerSet ret;
    for(int i = MIN; i <= MAX; i++) {
        ret.data[i] = data[i] | other.data[i];
    }
    return ret;
}

IntegerSet IntegerSet::intersectionOfSets(const IntegerSet & other) {
    IntegerSet ret;
    for(int i = MIN; i <= MAX; i++) {
        ret.data[i] = data[i] & other.data[i];
    }
    return ret;
}

void IntegerSet::insertElment(int x) {
    if (x < MIN || x > MAX) return;
    data[x] = 1;
}

void IntegerSet::deleteElements(int x) {
    if (x < MIN || x > MAX) return;
    data[x] = 0;
}

void IntegerSet::print() {
    std::cout << "{ ";
    bool first = true, empty = true;
    for(int i = MIN; i <= MAX; i++) {
        if (data[i]) {
            empty = false;
            if (first) {
                first = false;
            } else {
                std::cout << ", ";
            }
            std::cout << i;
        }
    }
    if (empty) {
        std::cout << "---";
    }
    std::cout << " }";
}

bool IntegerSet::isEqual(const IntegerSet & other) {
    for(int i = MIN; i <= MAX; i++) {
        if (data[i] != other.data[i]) {
            return false;
        }
    }
    return true;
}
