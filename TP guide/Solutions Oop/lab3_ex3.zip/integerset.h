#ifndef INTEGERSET_H_
#define INTEGERSET_H_


class IntegerSet {
    public:
        IntegerSet();
        IntegerSet unionOfSets(const IntegerSet&);
        IntegerSet intersectionOfSets(const IntegerSet&);
        void insertElment(int);
        void deleteElements(int);
        void print();
        bool isEqual(const IntegerSet&);
    private:
        static const int MIN = 0;
        static const int MAX = 100;
        bool data[MAX - MIN + 1];
};


#endif // INTEGERSET_H_
