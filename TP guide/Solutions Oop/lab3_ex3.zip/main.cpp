#include "integerset.h"
#include <iostream>

using namespace std;

int main() {

    IntegerSet s1;
    cout << "s1 = ";
    s1.print();
    cout << endl;

    IntegerSet s2;
    s2.insertElment(10);
    s2.insertElment(30);
    s2.insertElment(10);
    cout << "s2 = ";
    s2.print();
    cout << endl;

    IntegerSet s3 = s2.unionOfSets(s1);
    cout << "s3 = s1 U s2 = ";
    s3.print();
    cout << endl;

    s2.deleteElements(10);
    cout << "s2' = s2 \\ {10} = ";
    s2.print();
    cout << endl;

    s2.deleteElements(40);
    cout << "s2'' = s2' \\ {40} = ";
    s2.print();
    cout << endl;

    IntegerSet s4;
    s4.insertElment(30);
    cout << "s4 = ";
    s4.print();
    cout << endl;

    cout << "isEqual(s2'', s4) = " << s4.isEqual(s2);
    cout << endl;

    return 0;
}
