#include "purchasesaccount.h"
#include <iostream>
#include <iomanip>

double PurchasesAccount::annualDiscountRate = 0.0;

PurchasesAccount::PurchasesAccount(double d) {
    purchasesBalance = d;
}

void PurchasesAccount::modifyDiscountRate(double rate) {
    if (rate >= 0. && rate <= 1.0) {
        annualDiscountRate = rate;
    } else {
        std::cerr << "Invalid discount rate: " << rate << std::endl;
    }
}

void PurchasesAccount::calculateMonthlyDiscount() {
    purchasesBalance = purchasesBalance - purchasesBalance * (annualDiscountRate / 12);
}

void PurchasesAccount::print() {
    // In order to print the balance as a column and use std::setw,
    // we need to put into std::cout *one* string.
    // To do so, we format the balance in a std::stringstream, and then
    // flush it to std::cout.
    std::stringstream ss;
    ss << std::setprecision(2) << std::fixed << purchasesBalance << " DA";
    std::cout << ss.str();
}
