#ifndef PURCHASESACCOUNT_H_
#define PURCHASESACCOUNT_H_

class PurchasesAccount {
    public:
        PurchasesAccount(double = 0.);
        void calculateMonthlyDiscount();
        static void modifyDiscountRate(double);
        void print();
    private:
        static double annualDiscountRate;
        double purchasesBalance;
};


#endif // PURCHASESACCOUNT_H_
