#include "purchasesaccount.h"
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char *argv[]) {

    PurchasesAccount customer1(200000), customer2(300000);
    PurchasesAccount::modifyDiscountRate(0.02);

    cout << "Initial balances"
         << endl
         << setw(6) << ""
         << setw(20) << "Customer #1"
         << setw(20) << "Customer #2"
         << endl;
    cout << setw(6) << "";
    cout << setw(20); customer1.print();
    cout << setw(20); customer2.print();
    cout << endl;

    cout << endl
         << "Balances for year #1 with 2% dicount rate:"
         << endl
         << setw(6) << "Month"
         << setw(20) << "Customer #1"
         << setw(20) << "Customer #2"
         << endl;

    for(int month = 1; month <= 12; month++) {
        customer1.calculateMonthlyDiscount();
        customer2.calculateMonthlyDiscount();
        cout << setw(6) << month;
        cout << setw(20); customer1.print();
        cout << setw(20); customer2.print();
        cout << endl;
    }

    PurchasesAccount::modifyDiscountRate(0.03);
    customer1.calculateMonthlyDiscount();
    customer2.calculateMonthlyDiscount();
    cout << endl
         << "Balances for the next month with %3 discount rate:"
         << endl
         << setw(6) << "Month"
         << setw(20) << "Customer #1"
         << setw(20) << "Customer #2"
         << endl;
    cout << setw(6) << 1;
    cout << setw(20); customer1.print();
    cout << setw(20); customer2.print();
    cout << endl;

    return 0;
}
