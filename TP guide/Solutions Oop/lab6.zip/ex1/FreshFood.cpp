/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "FreshFood.h"

FreshFood::FreshFood(long pcode, string pname, float pweight, float price):Product(pcode, pname){

    setweight(pweight);
    setprice(price);
}

float FreshFood::getweight() const{

    return weight;
}

float FreshFood::getprice() const{

    return price_kg;
}

void FreshFood::setweight(float pweight){

    weight = pweight > 0 ?  pweight : 0;
}

void FreshFood::setprice(float price){

    price_kg  = price > 0 ?  price : 0;
}

void FreshFood::scanner(){

    Product::scanner();

    float pweight;
    cout << "Please enter the weight of the product: ";
    cin >> pweight;
    setweight(pweight);

    float price;
    cout << "Please enter the price/kg of the product: ";
    cin >> price;
    setprice(price);
}

void FreshFood::printer() const{

    Product::printer();
    cout << "The weight of the product is: " << weight << " Kg" << endl;
    cout << "The price/kg of the product is: " << price_kg << " DZD" << endl;
}

