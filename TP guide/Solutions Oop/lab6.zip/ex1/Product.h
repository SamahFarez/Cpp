/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <string>
#ifndef PRODUCT_H_INCLUDED
#define PRODUCT_H_INCLUDED

using namespace std;

class Product{

public:
    Product(long=0, string="");
    long getCode() const;
    void setCode(long);
    void scanner();
    void printer() const;

// "private" data members provide better protection than "protected"
private:
    long barcode;
    string name;
};

#endif // PRODUCT_H_INCLUDED
