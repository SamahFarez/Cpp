/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "PrepackedFood.h"

PrepackedFood::PrepackedFood(long pcode, string pname, float price):Product(pcode, pname){

    setprice(price);
}

float PrepackedFood::getprice() const{

    return unit_price;
}

void PrepackedFood::setprice(float price){

    unit_price = price > 0 ?  price : 0;
}

void PrepackedFood::scanner(){

    Product::scanner();

    float price;
    cout << "Please enter the unit price of the product: ";
    cin >> price;
    setprice(price);
}

void PrepackedFood::printer() const{

    Product::printer();
    cout << "The unit price of the product is: " << unit_price << " DZD" << endl;
}
