/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Product.h"

Product::Product(long pcode, string pname){

    barcode = pcode;
    name = pname;
}

long Product::getCode() const{

    return barcode;
}

void Product::setCode(long code){

    barcode = code;
}

void Product::scanner(){

    cout << "\nPlease enter the bar code of the product: ";
    cin >> barcode;

    cout << "Please enter the name of the product: ";
    getline(cin >> ws, name);
}

void Product::printer() const{

    cout << "\nThe bar code of the product is: " << barcode << endl;
    cout << "The name of the product is: " << name << endl;
}
