/*************************/
/* Author: Sami Belkacem */
/*************************/

#ifndef FRESHFOOD_H_INCLUDED
#define FRESHFOOD_H_INCLUDED

#include "Product.h"

class FreshFood: public Product{

public:
    FreshFood(long=0, string="", float=0, float=0);
    float getweight() const;
    float getprice() const;
    void setweight(float);
    void setprice(float);
    void scanner();
    void printer() const;

private:
    float weight;
    float price_kg;
};

#endif // FRESHFOOD_H_INCLUDED
