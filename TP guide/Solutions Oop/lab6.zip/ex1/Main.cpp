/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Product.h"
#include "PrepackedFood.h"
#include "FreshFood.h"

using namespace std;

int main(){

    cout << "Product:" << endl;
    Product P1;
    P1.printer();

    Product P2;
    P2.scanner();
    P2.printer();

    cout << "\nPrepacked Food:" << endl;
    PrepackedFood P3;
    P3.printer();

    PrepackedFood P4;
    P4.scanner();
    P4.printer();

    cout << "\nFresh Food:" << endl;
    FreshFood P5;
    P5.printer();

    FreshFood P6;
    P6.scanner();
    P6.printer();
}
