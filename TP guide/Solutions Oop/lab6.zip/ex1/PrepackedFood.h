/*************************/
/* Author: Sami Belkacem */
/*************************/

#ifndef PREPACKEDFOOD_H_INCLUDED
#define PREPACKEDFOOD_H_INCLUDED

#include "Product.h"

class PrepackedFood: public Product{

public:
    PrepackedFood(long=0, string="", float=0);
    float getprice() const;
    void setprice(float);
    void scanner();
    void printer() const;

private:
    float unit_price;
};

#endif // PREPACKEDFOOD_H_INCLUDED
