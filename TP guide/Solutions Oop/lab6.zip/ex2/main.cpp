/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>

using namespace std;

class Mammals{

public:
    void print(){ cout << "I am a Mammal" << endl; }
};

class MarineAnimals{

public:
    void print(){ cout << "I am a Marine Animal" << endl; }
};

class BlueWhale: public Mammals, public MarineAnimals{

public:
    void print(){ cout << "I belong to both the categories: Mammals and Marine Animals" << endl; }
};

int main()
{
    // Question 1
    cout << "Object of Mammal:" << endl;
    Mammals A1;
    A1.print();

    // Question 2
    cout << "\nObject of MarineAnimal:" << endl;
    MarineAnimals A2;
    A2.print();

    // Question 3
    cout << "\nObject of BlueWhale:" << endl;
    BlueWhale A3;

    // Question 4
    A3.print();
    A3.Mammals::print();
    A3.MarineAnimals::print();
}
