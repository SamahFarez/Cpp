/*************************/
/* Author: Sami Belkacem */
/*************************/

#ifndef VEHICLE_H_INCLUDED
#define VEHICLE_H_INCLUDED

class Vehicle{

public:
    Vehicle(double=0, double=0);
    void print() const;

private:
    double price;
    double mileage;
};

#endif // VEHICLE_H_INCLUDED
