/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Car.h"

using namespace std;

Car::Car(double p, double m, double c, int w, int s, char f):Vehicle(p, m){

    coast = c > 0 ? c : 0;
    warranty = w >= 0 ? w : 0;
    seating = s > 0 ? s : 0;
    fuel = (toupper(f)=='D' || toupper(f)=='P') ? f : ' ';
}

void Car::print() const{

    Vehicle::print();
    cout << "The coast of the car is: " << coast << " DZD" << endl;
    cout << "The warranty of the car is: " << warranty << " year(s)" << endl;
    cout << "The seating capacity of the car is: " << seating << " places" << endl;
    cout << "The fuel type of the car is: " << fuel << endl;
}
