/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <string>
#ifndef AUDI_H_INCLUDED
#define AUDI_H_INCLUDED
#include "Car.h"

using namespace std;

class Audi: public Car{

public:
    Audi(double=0, double=0, double=0, int=0, int=0, char=' ', string="");
    void print() const;

private:
    string model;
};

#endif // AUDI_H_INCLUDED
