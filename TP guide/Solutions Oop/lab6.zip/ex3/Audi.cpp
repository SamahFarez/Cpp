/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Audi.h"

Audi::Audi(double p, double m, double c, int w, int s, char f, string mo):Car(p, m, c , w, s, f){

    model = mo;
}

void Audi::print() const{

    Car::print();
    cout << "The model of the Audi is: " << model << endl;
}
