/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <string>
#ifndef SCOOTER_H_INCLUDED
#define SCOOTER_H_INCLUDED
#include "Bike.h"

using namespace std;

class Scooter: public Bike{

public:
    Scooter(double=0, double=0, int=0, int=0, char=' ', char=' ', float=0, string="");
    void print() const;

private:
    string model;
};

#endif // SCOOTER_H_INCLUDED
