/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Audi.h"
#include "Scooter.h"

using namespace std;

int main(){

    cout << "Default Audi car: " << endl;
    Audi A1;
    A1.print();

    cout << "\nAudi car: " << endl;
    Audi A2(600, 50000, 500, 5, 5, 'D', "A3");
    A2.print();

    cout << "\nDefault Scooter bike: " << endl;
    Scooter S1;
    S1.print();

    cout << "\nScooter bike: " << endl;
    Scooter S2(50, 5000, 4, 5, 'A', 'S', 9, "Yamaha");
    S2.print();
}
