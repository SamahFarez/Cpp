/*************************/
/* Author: Sami Belkacem */
/*************************/

#ifndef BIKE_H_INCLUDED
#define BIKE_H_INCLUDED
#include "Vehicle.h"

class Bike:public Vehicle{

public:
    Bike(double=0, double=0, int=0, int=0, char=' ', char=' ', float=0);
    void print() const;

private:
    int cylinders;
    int gears;
    char cooling;
    char wheel;
    float tank_size;
};

#endif // BIKE_H_INCLUDED
