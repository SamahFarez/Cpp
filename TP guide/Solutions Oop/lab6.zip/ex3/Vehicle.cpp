/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Vehicle.h"

using namespace std;

Vehicle::Vehicle(double p, double m){

    price = p > 0 ? p : 0;
    mileage = m >= 0 ? m : 0;
}

void Vehicle::print() const{

    cout << "\nThe price of the vehicle is: " << price << " DZD" << endl;
    cout << "The mileage of the vehicle is: " << mileage << " Km" << endl;
}
