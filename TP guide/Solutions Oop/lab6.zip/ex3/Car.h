/*************************/
/* Author: Sami Belkacem */
/*************************/

#ifndef CAR_H_INCLUDED
#define CAR_H_INCLUDED
#include "Vehicle.h"

class Car: public Vehicle{

public:
    Car(double=0, double=0, double=0, int=0, int=0, char=' ');
    void print() const;

private:
    double coast;
    int warranty;
    int seating;
    char fuel;
};

#endif // CAR_H_INCLUDED
