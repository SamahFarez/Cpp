/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Scooter.h"

Scooter::Scooter(double p, double m, int cy, int g, char co, char w, float t, string mo):Bike(p, m, cy, g, co, w, t){

    model = mo;
}

void Scooter::print() const{

    Bike::print();
    cout << "The model of the scooter is: " << model << endl;
}
