/*************************/
/* Author: Sami Belkacem */
/*************************/

#include <iostream>
#include "Bike.h"

using namespace std;

Bike::Bike(double p, double m, int cy, int g, char co, char w, float t):Vehicle(p, m){

    cylinders = cy > 0 ? cy : 0;
    gears = g > 0 ? g : 0;
    cooling = (toupper(co)=='A' || toupper(co)=='L' || toupper(co)=='O') ? co : ' ';
    wheel = (toupper(w)=='A' || toupper(w)=='S') ? w : ' ';
    tank_size = t > 0 ? t : 0;
}

void Bike::print() const{

    Vehicle::print();
    cout << "The number of cylinders of the bike is: " << cylinders << endl;
    cout << "The number of gears of the bike is: " << gears << endl;
    cout << "The cooling type of the bike is: " << cooling << endl;
    cout << "The wheel type of the bike is: " << wheel << endl;
    cout << "The tank size of the bike is: " << tank_size << " inches" << endl;
}
