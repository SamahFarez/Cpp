#include "date.h"
#include <iostream>
using namespace std;

Date::Date(int m, int d, int y) {
    setDate(m, d, y);
}

bool Date::isLeapYear() {
    return
        (year % 400 == 0)
     || (year % 4 == 0 && year % 100 != 0);
}

int Date::monthDays() {
    switch (month) {
        case 1: case 3: case 5:
        case 7: case 8: case 10:
        case 12:
            return 31;

        case 2:
            return (isLeapYear() ? 29 : 28);

        default:
            return 30;
    }
}

void Date::setDate(int m, int d, int y) {
    if (m >= 1 && m <= 12) {
        month = m;
    } else {
        month = 1;
    }

    day = ( d >= 1 && d <= monthDays() ) ? d : 1;

    year = y;
}

void Date::print() {
    cout << month << '-' << day << '-' << year;
}

int Date::getMonth() {
    return month;
}

int Date::getDay() {
    return day;
}

int Date::getYear() {
    return year;
}

void Date::nextDay() {
    day++;
    if (day == monthDays() + 1) {
        day = 1;
        month++;
        if (month == 13) {
            month = 1;
            year++;
        }
    }
}
