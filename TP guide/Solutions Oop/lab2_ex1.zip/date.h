#ifndef _DATE_H_
#define _DATE_H_

class Date {
    public:
        Date( int = 1, int = 1, int = 1990);
        void setDate( int, int, int );
        void print();
        int getMonth();
        int getDay();
        int getYear();
        bool isLeapYear();
        void nextDay();
        int monthDays();

    private:
        int month;
        int day;
        int year;
};

#endif // _DATE_H_
