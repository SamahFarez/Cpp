#include "date.h"
#include <iostream>

using namespace std;

int main() {
    const int MAXDAYS = 160;
    Date date1( 10, 2, 1998 ), date2;

    cout << "date1 = ";
    date1.print();
    cout << "\ndate2 = ";
    date2.print();
    cout << endl;

    for ( int loop = 1; loop <= MAXDAYS; ++loop ) {
        date1.nextDay();
    }
    cout << "date1 + " << MAXDAYS << " days = ";
    date1.print();
    cout << endl;
    return 0;
}
