#include "BitVector.h"
#include "Vector.h"
#include <ostream>

void BitVector::print(ostream & out) const {
  out << "{";
  for(int i = 0; i < n - 1; i++) {
    out << (elements[i] ? "true" : "false") << ", ";
  }
  if (n >= 1) {
    out << (elements[n - 1] ? "true" : "false");
  }
  out << "}";
}

BitVector BitVector::operator+(const BitVector & v) {
  BitVector result(std::max(n, v.n));
  for(int i = 0; i < result.n; i++) {
    result.elements[i] = get(i) || v.get(i);
  }
  return result;
}

int BitVector::operator*(const BitVector & v) {
  int result = 0;
  for(int i = 0; i < std::min(n, v.n); i++) {
    result += get(i) && v.get(i);
  }
  return result;
}
