#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>
using std::ostream;

class Vector {
  friend ostream & operator<<(ostream &, const Vector &);
  public:
    Vector(int);
    Vector(int, int[]);
    virtual ~Vector();
    virtual void print(ostream&) const;
    int get(int) const;
    void set(int, int);
    Vector operator+(const Vector &);
    int operator*(const Vector &);

  protected:
    int n;
    int *elements;
};

#endif // VECTOR_H
