#include "Vector.h"

class BitVector : public Vector {
  public:
    BitVector(int n) : Vector(n) { }
    BitVector(int n, bool a[]) : Vector(n) {
      for(int i = 0; i < n; i++) {
        elements[i] = a[i];
      }
    }
    void print(ostream&) const;
    BitVector operator+(const BitVector &);
    int operator*(const BitVector &);
};
