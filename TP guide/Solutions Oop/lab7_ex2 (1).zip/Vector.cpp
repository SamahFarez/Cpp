#include "Vector.h"
#include <algorithm>
#include <iostream>
#include <ostream>

Vector::Vector(int n_) {
  if (n_ <= 0) {
    n = 0;
    elements = nullptr;
  } else {
    n = n_;
    elements = new int[n];
    for(int i = 0; i < n; i++) {
      elements[i] = 0;
    }
  }
}

Vector::Vector(int n_, int a_[]) {
  if (n_ <= 0) {
    n = 0;
    elements = nullptr;
  } else {
    n = n_;
    elements = new int[n];
    for(int i = 0; i < n; i++) {
      elements[i] = a_[i];
    }
  }
}

Vector::~Vector() {
  if (n > 0) {
    delete [] elements;
  }
}

void Vector::set(int i, int v) {
  if (i < 0 || i >= n) {
    return;
  }
  elements[i] = v;
}

int Vector::get(int i) const {
  if (i < 0 || i >= n) {
    return 0;
  }
  return elements[i];
}

ostream& operator<<(ostream& out, const Vector & v) {
  v.print(out);
  return out;
}

void Vector::print(ostream & out) const {
  out << "[";
  for(int i = 0; i < n - 1; i++) {
    out << elements[i] << ", ";
  }
  if (n >= 1) {
    out << elements[n - 1];
  }
  out << "]";
}


Vector Vector::operator+(const Vector & v) {
  Vector result(std::max(n, v.n));
  for(int i = 0; i < result.n; i++) {
    result.elements[i] = get(i) + v.get(i);
  }
  return result;
}

int Vector::operator*(const Vector & v) {
  int result = 0;
  for(int i = 0; i < std::min(n, v.n); i++) {
    result += get(i) * v.get(i);
  }
  return result;
}
