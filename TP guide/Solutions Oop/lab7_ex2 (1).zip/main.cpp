#include "Vector.h"
#include "BitVector.h"
#include <iostream>
using namespace std;

int main() {

  int a1[5]={1,2,3,4,5};
  Vector v1(5, a1);

  int a2[5]={6,7,8,9,10};
  Vector v2(5, a2);

  cout << "v1 = " << v1 << endl;
  cout << "v2 = " << v2 << endl;
  cout << "v1 + v2 = " << (v1 + v2) << endl;
  cout << "v1 * v2 = " << (v1 * v2) << endl;

  bool a3[5] = {true, false, false, true, true};
  BitVector v3(5, a3);

  bool a4[5] = {false, false, false, true, false};
  BitVector v4(5, a4);
  
  cout << "v3 = " << v3 << endl;
  cout << "v4 = " << v4 << endl;
  cout << "v3 + v4 = " << (v3 + v4) << endl;
}
