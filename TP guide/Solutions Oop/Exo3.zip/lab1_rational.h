#ifndef LAB1_RATIONAL_H
#define LAB1_RATIONAL_H

class Rational{

friend double GetFloat(const Rational &r);  // friend function to get the double value of a Rational

// passing a parameter by value creates a copy of the parameter (more space and execution time)
// Rational&: we pass the parameter by reference because it requires less memory and execution time
// const Rational&: we use const to make sure we don't change the value of the parameter inside the function
public:
	Rational(int = 0, int = 1);
	Rational addition(const Rational&);
	Rational subtraction(const Rational&);
	Rational multiplication(const Rational&);
	Rational division(const Rational&);
	void printRational(void);
	void printRationalAsDouble(void);

private:
	int numerator;
	int denominator;
	void reduction(void);
};

#endif
