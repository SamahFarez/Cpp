#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED

#include "lab1_rational.h"

class Point{

public:
    Point();
    Point(const Rational&, const Rational&);
    Rational getX() const;
    Rational getY() const;
    void setX(const Rational&);
    void setY(const Rational&);
    void setXY(const Rational&, const Rational&);
    void print();

private:
    Rational X;
    Rational Y;
};

#endif
