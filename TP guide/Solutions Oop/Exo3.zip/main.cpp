#include <iostream>
#include "segment.h"

using namespace std;

 double GetFloat(const Rational &r){

   return double (r.numerator) / r.denominator;
 }

int main(){

    // Point with default values
    Point P;
    cout << "The default point P: ";
    P.print();

    // Segment with default values
    Segment S;
    cout <<"Segment AB dimension/distance is: " << S.Getdimension() << "\n" << endl;

    // Point A
    Rational r1(2,3);
    Rational r2(4,5);
    Point pA(r1,r2);
    cout << "The point A: ";
    pA.print();

    // Point B
    Rational r3(2,1);
    Rational r4(3,1);
    Point pB(r3,r4);
    cout << "The point B: ";
    pB.print();

    // Segment S1
    Segment S1(pA,pB);
    cout <<"Segment AB dimension/distance is: " << S1.Getdimension() << "\n" << endl;

    // Testing set functions

    // Point A
    Rational r5(12,13);
    Rational r6(24,5);
    pA.setX(r5);
    pA.setY(r6);
    cout << "The point A after modification: ";
    pA.print();

    // Point B
    Rational r7(5,13);
    Rational r8(7,5);
    pB.setX(r7);
    pB.setY(r8);
    cout << "The point B after modification: ";
    pB.print();

    // Segment 1
    S1.setA(pA);
    S1.setB(pB);
    cout << "Segment AB dimension/distance is: " << S1.Getdimension() << "\n" << endl;

    return 0;
}
