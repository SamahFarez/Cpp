#ifndef SEGMENT_H_INCLUDED
#define SEGMENT_H_INCLUDED

#include "point.h"

class Segment{

public:
    Segment();                                    // constructor with default values
    Segment(const Point&, const Point&);
    Point GetA() const;
    Point GetB() const;
    void setA(const Point&);
    void setB(const Point&);
    void setAB(const Point&, const Point&);
    double Getdimension();

private:
    Point A;
    Point B;
};

#endif
