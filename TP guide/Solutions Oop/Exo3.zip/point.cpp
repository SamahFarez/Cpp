#include <iostream>
#include "point.h"

using namespace std;

Point::Point(){

    X = Rational();
    Y = Rational();
}

Point::Point(const Rational &x, const Rational &y){

    X = x;
    Y = y;
}

Rational Point::getX()const{ return X; }

Rational Point::getY()const{ return Y; }

void Point::setX(const Rational &x){ X = x; }

void Point::setY(const Rational &y){ Y = y; }

void Point::setXY(const Rational &x, const Rational &y){ setX(x); setY(y); }

void Point::print(){

    cout << "(" ;
    X.printRational();
    cout << "," ;
    Y.printRational();
    cout << ")" << "\n" << endl;
}
