#include <iostream>
#include <cmath>
#include "segment.h"

using namespace std;

Segment::Segment(){

    A = Point();
    B = Point();
}

Segment::Segment(const Point &x, const Point &y){

    A = x;
    B = y;
}

Point Segment::GetA()const{ return A; }

Point Segment::GetB()const{ return B; }

void Segment::setA(const Point &p1){ A=p1; }

void Segment::setB(const Point &p2){ B=p2; }

void Segment::setAB(const Point &p1, const Point &p2){ setA(p1); setB(p2); }

// Distance between two points (A,B) = sqrt( (Bx - Ax)� + (By - Ay)� )
double Segment::Getdimension(){

   // (Bx - Ax)�
   Rational r1 = A.getX().subtraction(B.getX());
   r1 = r1.multiplication(r1);

   // (By - Ay)�
   Rational r2 = A.getY().subtraction(B.getY());
   r2 = r2.multiplication(r2);

   // sqrt( (Bx - Ax)� + (By - Ay)� )
   r1 = r1.addition(r2);
   return sqrt(GetFloat(r1));
}
