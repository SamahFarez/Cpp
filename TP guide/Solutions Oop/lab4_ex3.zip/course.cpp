#include "course.h"
#include <cstddef>
#include <iostream>


Course::Course(const string& n, int c) {
    if (c < 0) {
        std::cerr << "Invalid course capcity: " << c << std::endl;
        c = 1;
    }
    courseName = n;
    capacity = c;
    numberOfStudents = 0;
    students = new string[capacity];
}

Course::~Course() {
    delete [] students;
}

string Course::getCourseName() const {
    return courseName;
}

void Course::addStudent(const string& name) {
    if (numberOfStudents == capacity) {
        std::cerr << "Course '" << courseName << "' is full";
        return;
    }
    students[numberOfStudents] = name;
    numberOfStudents++;
}

void Course::dropStudent(const string &name) {
    int i;
    for(i = 0; i < numberOfStudents; i++) {
        if (students[i].compare(name) == 0) {
            break;
        }
    }
    // Check if we went through the entire array
    if (i == numberOfStudents) {
        std::cerr << "Student " << name << " not found in Course '" << courseName << "'" << std::endl;
        return;
    }
    // Otherwise move the next cells one position back
    for(int j = i; j < numberOfStudents - 1; j++) {
        students[j] = students[j+1];
    }
    numberOfStudents--;
}

string* Course::getStudents() const {
    return students;
}

int Course::getNumberOfStudents() const {
    return numberOfStudents;
}
