#include "course.h"
#include <iostream>
#include <sstream>

using namespace std;

int main() {
    Course oop("Object-Oriented Programming", 10);
    oop.addStudent("S1");
    oop.addStudent("S2");
    oop.addStudent("S3");
    oop.dropStudent("S2");
    oop.dropStudent("S4");

    cout << "Students of Course '" << oop.getCourseName() << "' are:" << endl;
    string *students = oop.getStudents();
    for(int i = 0; i < oop.getNumberOfStudents(); i++) {
        cout << "  - " << students[i] << endl;
    }

    Course algebra("Linear Algebra", 10);
    for(int i = 1; i <= 10; i++) {
        stringstream ss;
        ss << "S" << i;
        algebra.addStudent(ss.str());
    }
    algebra.dropStudent("S8");
    algebra.dropStudent("S10");

    cout << "Students of Course '" << algebra.getCourseName() << "' are:" << endl;
    students = algebra.getStudents();
    for(int i = 0; i < algebra.getNumberOfStudents(); i++) {
        cout << "  - " << students[i] << endl;
    }
    return 0;
}
